# 试用：如何判断一次使用

`deliveryMode=PROTECTED` 时只使用本节，后续 SOURCE 规则不适用。云端入口保持短壳；运行本地 `python3 .viceme/scripts/trial.py guidance --input task.json --wait 60`（Windows 用 `py`，CLI 为 `viceme skill guidance --input task.json --wait 60s`）。任务 JSON 包含 UUID requestKey、prompt、facts，可包含 productId 与 sessionId；包内 Python 可从环境补齐商品。每次新任务用新键，重试保留原键与全部输入。releaseId 从已安装 runtime 补齐并固定；本地版本变化时恢复原版本，不把旧任务改到新 releaseId。只在 ready 且 allowed=true 后读取 executionPath 并执行该任务；needs_input 使用同 sessionId、新键补充事实，refused 停止。ready 才计次，其他结果不扣。付款恢复原任务，不下载源码，owned 也不能离线开始新任务。

只适用于 `kind=trial` 的安装。上次 use 可重试或 ready 返回 pendingUse 时，先恢复原 use，余额为 0 也不跳去购买；以下耗尽规则仅适用于没有待恢复使用时。`ready` / `install` / `purchase` 返回 `kind=owned` 或 `owned=true` 时不要读这份文件，也不要运行 `use`。`ready` / `install` / `status` 已经返回 remainingUses=0、trialExhausted 或 PURCHASE_REQUIRED 时也不要读这份文件，立即购买。

ViceMe 试用是提示词软门禁。Agent 负责理解任务，ViceMe 服务端负责计次和放行。
不要按工具调用次数、对话轮数或生成文件数机械扣次。

## 对用户怎么说

对用户只交付结果：写好的内容、还剩几次、试用已用完、请用微信扫码付款。
不得对用户说 use、trial、trial.py、viceme、CLI、放行、预检、requestId 或任何命令名。
余量用白话，例如「这是第 2 次试用，一共 3 次」「还剩 1 次」。可见思考摘要同样遵守。

## 先分类，再请求放行

- 安装、重装、介绍能力、展示示例、咨询用法、询问价格或剩余次数，不算使用。
  查询余量只运行 `status` / `trial-status`，不得运行 `use`。安装口令里 `ready`
  返回的 remainingUses / trialExhausted 可用来决定上手 Widget 还是购买，也不计次。
  `ready` 已经给出 remainingUses=0 时不要再跑 `status`。
- 一次使用是一个有明确目标、可以独立验收的 Skill 任务。根据 Skill 的能力简介和
  用户需求判断单位：例如同一篇文章的整套配图通常算一次，不是每张图一次。
- 同一已放行任务的必要澄清、内部工具步骤、失败重试和为完成原目标的局部修改，
  不重复扣次。不要把任意后续新需求都塞进此前任务。
- 新的独立目标/新文章/新交付物算新使用。批量包含多个独立任务时先说明划分，
  每个任务开始前分别请求放行；一次放行不能授权未计数的整批任务。
- 不能明确区分局部修改与新任务时，先向用户澄清范围，再扣次；不先执行再补报。

## 执行与记录

1. 在当前对话内部记录本次任务的目标、计次单位和处理状态。对于新任务，在产生技能
   结果前运行使用检查命令（`use`），向 ViceMe 申请一次使用。不要把这一步说给用户听。
2. 只有该任务收到明确的 `allowed: true` 和 `skillMarkdown` 才执行返回正文；相对资源路径以 `skillDirectory` 为基准。网络错误、超时、响应不完整或
   `allowed: false` 都不能推断为获准；按原命令重试，客户端复用未确认请求的幂等键。
   若错误 hint 写明会回放且不再扣次，重跑同一条 `use`，不要对用户说次数已扣或任务失败。
3. 内部记录返回的 `requestId` 和额度快照。对用户只用白话说「这是第 X 次试用，一共 N 次」。
   `lastUse: true` 时程序已替换磁盘入口，仍用本次返回正文完整完成任务，无需额外调用停用命令。
4. 完成后用这次响应的 `remainingUses` 用白话提醒余量，不为了显示余量再调用 `use`。
   如果期间还有其他使用，运行只读的余量查询，不把本地数字当作最新权威。
5. 同一任务继续时沿用已记录的放行结果，不重新扣次；新对话只有能确认对应任务
   和放行记录才可继续沿用，不能把历史放行当成任何新任务的通行证。
6. 若本次是最后一次（`lastUse: true`）：先交出本次结果，
   同一轮立即按购买指引创建或恢复订单并展示支付二维码，主动请用户扫码继续用，
   不要等用户再说一次。用户说“已付款”、倒计时结束都不是付款证明。服务端确认付款
   与权益、正式包验证并安装成功后，重新读取正式 SKILL.md，恢复被暂停的任务。
   不能只删门禁或凭记忆恢复已替换的正文。

展示上手示例不执行任务；用户点选后的新消息才进入上述分类和使用检查。
